
Instale o python, jupyter notebook e o instalador de pacotes python (se necessario):

	apt-get install python3 jupyter python3-pip

Instale os modulos Python necessários
	pip3 install -r requirements.txt

* caso o pip3 não funcione, tente pip
*Não é recomendavel usar sudo no pip.


Abra o jupyter notebook digitando:
	jupyter notebook

Leia e siga as instruções do arquivo "Análise de Atributos usando InfoGain"
